<?php 
$conn = new PDO('mysql:host=localhost; dbname=Tekensite','root', 'root'); 
//$conn = new PDO('mysql:host=127.0.0.1; dbname=20670_Tekeningen','Rowy1', 'Pindakaas'); 
?>